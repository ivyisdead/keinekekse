<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Retrieve user's address details from the database
require_once "config.php";
$sql = "SELECT address, city, region, nation FROM users WHERE id = ?";
if($stmt = mysqli_prepare($link, $sql)){
    mysqli_stmt_bind_param($stmt, "i", $_SESSION["id"]);
    if(mysqli_stmt_execute($stmt)){
        mysqli_stmt_bind_result($stmt, $address, $city, $region, $nation);
        mysqli_stmt_fetch($stmt);
    }
    mysqli_stmt_close($stmt);
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>
    <h1 class="my-5">Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</h1>
    <p>
        <a href="reset-password.php" class="btn btn-warning">Reset Your Password</a>
        <a href="logout.php" class="btn btn-danger ml-3">Sign Out of Your Account</a>
    </p>
    <div class="container">
        <h2>Your Address Details</h2>
        <ul class="list-group">
            <li class="list-group-item"><?php echo htmlspecialchars($address); ?></li>
            <li class="list-group-item"><?php echo htmlspecialchars($city); ?></li>
            <li class="list-group-item"><?php echo htmlspecialchars($region); ?></li>
            <li class="list-group-item"><?php echo htmlspecialchars($nation); ?></li>
        </ul>
    </div>
</body>
</html>
